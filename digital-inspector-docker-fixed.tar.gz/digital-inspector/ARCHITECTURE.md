# Digital Inspector - Техническое решение

## 🏗️ Архитектура системы

```
┌─────────────────────────────────────────────────────────────┐
│                      Frontend (HTML/JS)                      │
│  ┌────────────┐  ┌──────────────┐  ┌──────────────────────┐ │
│  │  Document  │  │   Preview    │  │   Results Panel      │ │
│  │    List    │  │   with Zoom  │  │  (Stats + Details)   │ │
│  └────────────┘  └──────────────┘  └──────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
                            │ HTTP/REST API
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Backend (FastAPI)                         │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  API Endpoints                                        │   │
│  │  • /api/upload  • /api/process  • /api/results      │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                   Document Detector                          │
│  ┌─────────────┐  ┌─────────────┐  ┌──────────────────┐    │
│  │ QR Detector │  │   Stamp     │  │    Signature     │    │
│  │  (QReader)  │  │  Detector   │  │    Detector      │    │
│  │             │  │ (Roboflow)  │  │  (Fine-tuned)    │    │
│  └─────────────┘  └─────────────┘  └──────────────────┘    │
└─────────────────────────────────────────────────────────────┘
```

## 🎯 Ключевые особенности

### 1. Модульная архитектура с тремя независимыми детекторами

**QR Code Detector**
- Библиотека: QReader (Large model)
- Особенности: 
  - Цветовая фильтрация для отсечения печатей
  - Геометрическая валидация (aspect ratio 0.7-1.3)
  - Порог уверенности: 50%

**Stamp Detector**
- Модель: Roboflow Custom Model (stamp-11sbo/2)
- Обучена на реальных строительных документах
- Детектирует цветные и монохромные печати

**Signature Detector**
- Custom fine-tuned модель (в процессе обучения)
- Предназначена для детекции рукописных подписей
- Интеграция готова через plug-and-play интерфейс

### 2. Оптимизация для laptop GPU (RTX 3060)

- DPI = 200 (баланс качество/производительность)
- Batch processing отключен (по одному файлу)
- CUDA memory management
- Опциональный fallback на CPU

### 3. REST API с асинхронной обработкой

```python
POST /api/upload          # Загрузка файлов → task_id
POST /api/process/{id}    # Запуск обработки
GET  /api/results/{id}    # Получение результатов
GET  /api/image/{id}/{f}  # Обработанное изображение
```

### 4. Интерактивный веб-интерфейс

- Drag & Drop загрузка
- Real-time preview с zoom
- Детальная статистика детекций
- Responsive design

## 📊 Формат выходных данных

### JSON Output
```json
{
  "filename": "doc.pdf",
  "pages": 2,
  "total_detections": 5,
  "detections": [
    {
      "type": "qr_code",
      "page": 1,
      "bbox": [100, 150, 200, 250],
      "confidence": 0.95,
      "width": 100,
      "height": 100
    }
  ],
  "output_image": "doc_processed.jpg",
  "status": "success"
}
```

### Visual Output
- Bounding boxes с цветовым кодированием:
  - 🟢 Зеленый: QR-коды
  - 🔵 Синий: Печати
  - 🔴 Красный: Подписи
- Confidence scores на каждой детекции
- Сохранение в PDF/JPG с аннотациями

## 🔧 Технологический стек

### Backend
- **FastAPI** - современный async веб-фреймворк
- **OpenCV** - обработка изображений
- **pdf2image** - конвертация PDF
- **QReader** - QR detection
- **Roboflow/Inference** - custom object detection

### Frontend
- **Vanilla JavaScript** - без фреймворков для простоты
- **HTML5/CSS3** - современный UI
- **Fetch API** - асинхронные запросы

### ML/CV
- **PyTorch** - для custom моделей
- **CUDA** - GPU ускорение
- **NumPy** - работа с массивами

## 🚀 Масштабируемость

### Текущая версия (v1.0)
- Обработка: 1 документ за раз
- Throughput: ~5-10 док/мин
- Hardware: Single GPU

### Возможности расширения (v2.0+)
```python
# Batch processing
async def process_batch(documents: List[Document]):
    tasks = [process_single(doc) for doc in documents]
    return await asyncio.gather(*tasks)

# Distributed processing
# Redis queue + Celery workers
# Kubernetes orchestration
```

## 📈 Метрики качества

### Планируемые метрики для питчинга
- **Accuracy**: % правильно детектированных объектов
- **Precision**: TP / (TP + FP)
- **Recall**: TP / (TP + FN)
- **F1-Score**: гармоническое среднее Precision и Recall
- **Processing Speed**: документов/минуту

### A/B Testing
```python
# Сравнение порогов confidence
confidence_thresholds = [0.3, 0.5, 0.7]
for threshold in thresholds:
    metrics = evaluate_model(test_set, threshold)
    log_metrics(threshold, metrics)
```

## 🎓 Инновационные подходы

### 1. Цветовая фильтрация для QR
```python
def is_colored_stamp(crop):
    hsv = cv2.cvtColor(crop, cv2.COLOR_BGR2HSV)
    saturation = hsv[:, :, 1].mean()
    return saturation > 25  # Печать vs QR
```

### 2. Multi-stage pipeline
```
PDF → Images → Detection → Filtering → Visualization → JSON
```

### 3. Fallback механизмы
- QR не найден → попытка с другими параметрами
- GPU недоступен → переключение на CPU
- Модель не загружена → graceful degradation

## 💡 Будущие улучшения

1. **Real-time processing** - WebSocket для live feedback
2. **OCR integration** - извлечение текста из печатей
3. **Document classification** - автоопределение типа документа
4. **Compliance checking** - валидация по правилам
5. **Multi-language support** - интернационализация

## 📝 Выводы для презентации

### Сильные стороны
✅ Модульная архитектура - легко добавлять новые детекторы
✅ Production-ready API - готово к интеграции
✅ User-friendly интерфейс - не требует обучения
✅ Оптимизировано под laptop GPU - доступно без облака
✅ Визуальные результаты - сразу видно что детектировано

### Что показывать на демо
1. Загрузка нескольких документов drag & drop
2. Быстрая обработка (показать время)
3. Интерактивный preview с zoom
4. Детальная статистика
5. JSON output для интеграций

### Возможности масштабирования
- Batch processing для 1000+ документов
- Cloud deployment (AWS/GCP)
- API для интеграции в существующие системы
- Mobile app версия
