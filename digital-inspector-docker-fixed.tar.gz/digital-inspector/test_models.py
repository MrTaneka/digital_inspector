#!/usr/bin/env python3
"""
Тестовый скрипт для проверки YOLOv8 моделей
Использование: python test_models.py
"""

import sys
import time
from pathlib import Path

def check_gpu():
    """Проверка доступности GPU"""
    print("="*60)
    print("1. GPU CHECK")
    print("="*60)
    
    try:
        import torch
        print(f"✓ PyTorch installed: {torch.__version__}")
        
        if torch.cuda.is_available():
            print(f"✓ CUDA available: {torch.version.cuda}")
            print(f"✓ GPU: {torch.cuda.get_device_name(0)}")
            vram = torch.cuda.get_device_properties(0).total_memory / 1e9
            print(f"✓ VRAM: {vram:.2f} GB")
            
            if vram < 4.5:
                print("⚠ Warning: Low VRAM, use yolov8s or yolov8n")
            
            return True
        else:
            print("⚠ CUDA not available, will use CPU")
            return False
    except ImportError:
        print("❌ PyTorch not installed")
        print("   Install: pip install torch torchvision")
        return False

def check_ultralytics():
    """Проверка ultralytics"""
    print("\n" + "="*60)
    print("2. ULTRALYTICS CHECK")
    print("="*60)
    
    try:
        from ultralytics import YOLO
        import ultralytics
        print(f"✓ Ultralytics installed: {ultralytics.__version__}")
        return True
    except ImportError:
        print("❌ Ultralytics not installed")
        print("   Install: pip install ultralytics")
        return False

def check_models():
    """Проверка наличия моделей"""
    print("\n" + "="*60)
    print("3. MODELS CHECK")
    print("="*60)
    
    models_dir = Path("models")
    
    if not models_dir.exists():
        print("❌ models/ directory not found")
        print("   Create: mkdir models")
        return False
    
    # Проверяем модели
    stamp_model = models_dir / "stamp_model.pt"
    sign_model = models_dir / "signature_model.pt"
    
    found = []
    missing = []
    
    if stamp_model.exists():
        size = stamp_model.stat().st_size / 1e6
        print(f"✓ stamp_model.pt found ({size:.1f} MB)")
        found.append(stamp_model)
    else:
        print("⚠ stamp_model.pt not found")
        missing.append("stamp_model.pt")
    
    if sign_model.exists():
        size = sign_model.stat().st_size / 1e6
        print(f"✓ signature_model.pt found ({size:.1f} MB)")
        found.append(sign_model)
    else:
        print("⚠ signature_model.pt not found")
        missing.append("signature_model.pt")
    
    if missing:
        print("\n📝 Missing models:")
        for m in missing:
            print(f"   - {m}")
        print("\n💡 Copy your trained models to models/ directory:")
        print("   cp runs/detect/train/weights/best.pt models/stamp_model.pt")
    
    return len(found) > 0, found

def test_model_loading(model_path):
    """Тестирование загрузки модели"""
    print("\n" + "="*60)
    print(f"4. LOADING TEST: {model_path.name}")
    print("="*60)
    
    try:
        from ultralytics import YOLO
        import torch
        
        start = time.time()
        model = YOLO(str(model_path))
        load_time = time.time() - start
        
        print(f"✓ Model loaded in {load_time:.2f}s")
        print(f"✓ Device: {model.device}")
        print(f"✓ Task: {model.task}")
        
        # Проверяем классы
        if hasattr(model, 'names'):
            print(f"✓ Classes: {model.names}")
        
        return model
    except Exception as e:
        print(f"❌ Error loading model: {e}")
        return None

def test_inference(model, model_name):
    """Тестирование inference"""
    print("\n" + "="*60)
    print(f"5. INFERENCE TEST: {model_name}")
    print("="*60)
    
    try:
        import numpy as np
        
        # Создаем тестовое изображение
        test_image = np.random.randint(0, 255, (640, 640, 3), dtype=np.uint8)
        
        print("Running inference on random image...")
        
        # Warmup
        _ = model(test_image, verbose=False)
        
        # Реальный тест
        times = []
        for i in range(5):
            start = time.time()
            results = model(test_image, conf=0.5, verbose=False)
            end = time.time()
            times.append(end - start)
        
        avg_time = np.mean(times)
        fps = 1 / avg_time
        
        print(f"✓ Average inference time: {avg_time*1000:.1f}ms")
        print(f"✓ FPS: {fps:.1f}")
        print(f"✓ Detections: {len(results[0].boxes)}")
        
        # Оценка производительности
        if avg_time < 0.05:
            print("🚀 Excellent! Very fast")
        elif avg_time < 0.1:
            print("✓ Good performance")
        elif avg_time < 0.2:
            print("⚠ Acceptable, consider optimization")
        else:
            print("⚠ Slow, consider using yolov8n or CPU")
        
        return True
    except Exception as e:
        print(f"❌ Error during inference: {e}")
        return False

def estimate_processing_speed(inference_time):
    """Оценка скорости обработки документов"""
    print("\n" + "="*60)
    print("6. SPEED ESTIMATION")
    print("="*60)
    
    # Учитываем PDF конвертацию и post-processing
    total_time_per_page = inference_time * 3 + 0.5  # x3 (QR+Stamp+Sign) + overhead
    
    print(f"Estimated processing time:")
    print(f"  • 1 page:  {total_time_per_page:.2f}s")
    print(f"  • 5 pages: {total_time_per_page * 5:.2f}s")
    print(f"  • 10 docs: {total_time_per_page * 10:.2f}s")
    
    docs_per_min = 60 / total_time_per_page
    print(f"\n📊 Throughput: ~{docs_per_min:.1f} documents/minute")

def main():
    """Главная функция"""
    print("\n" + "🔍 DIGITAL INSPECTOR - MODEL TEST SUITE")
    print("="*60)
    
    # 1. Проверка GPU
    has_gpu = check_gpu()
    
    # 2. Проверка ultralytics
    if not check_ultralytics():
        print("\n❌ Cannot continue without ultralytics")
        return
    
    # 3. Проверка моделей
    has_models, models = check_models()
    
    if not has_models:
        print("\n❌ No models found. Please add your trained models to models/")
        print("\n📝 Quick guide:")
        print("   1. Train model: model = YOLO('yolov8s.pt'); model.train(...)")
        print("   2. Copy weights: cp runs/detect/train/weights/best.pt models/stamp_model.pt")
        print("   3. Run this script again")
        return
    
    # 4-5. Тестирование каждой модели
    for model_path in models:
        model = test_model_loading(model_path)
        if model:
            if test_inference(model, model_path.stem):
                # Оценка скорости только для первой модели
                if model_path == models[0]:
                    estimate_processing_speed(0.05)  # Примерное время
    
    # Финальные рекомендации
    print("\n" + "="*60)
    print("7. RECOMMENDATIONS")
    print("="*60)
    
    if not has_gpu:
        print("💡 For better performance:")
        print("   - Install CUDA-enabled PyTorch")
        print("   - Use GPU if available")
    
    print("\n💡 Optimization tips:")
    print("   - Use yolov8s for balance (recommended)")
    print("   - Use yolov8n for speed")
    print("   - DPI=150 optimal for 4GB VRAM")
    print("   - Batch size 1-2 for GTX 1650 Ti")
    
    print("\n✅ Test complete!")
    print("\nNext steps:")
    print("   1. If tests passed: ./start.sh")
    print("   2. Upload test documents")
    print("   3. Check results")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n⚠ Test interrupted by user")
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
