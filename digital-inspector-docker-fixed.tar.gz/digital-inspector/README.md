# Digital Inspector 🔍

**Решение хакатона Armeta AI - автоматическое обнаружение подписей, печатей и QR-кодов на строительных документах**

## 📋 Описание

Digital Inspector - это веб-приложение на базе Computer Vision для автоматической инспекции строительных документов. Система детектирует три ключевых элемента:

1. **QR-коды** - для проверки лицензий и нормативной информации
2. **Печати/Штампы** - для валидации официальных документов  
3. **Подписи** - для подтверждения авторизации

## 🚀 Быстрый старт

### Требования

- Python 3.9+
- Poppler (для pdf2image)
- CUDA-совместимая GPU (опционально, но рекомендуется)

### Установка зависимостей

#### 1. Установите Poppler (для обработки PDF)

**Ubuntu/Debian:**
```bash
sudo apt-get install poppler-utils
```

**macOS:**
```bash
brew install poppler
```

**Windows:**
Скачайте с [официального сайта](https://blog.alivate.com.au/poppler-windows/) и добавьте в PATH

#### 2. Установите Python зависимости

```bash
cd digital-inspector
pip install -r requirements.txt
```

#### 3. Настройка API ключей

Для использования Roboflow модели создайте файл `.env` в папке `backend/`:

```env
ROBOFLOW_API_KEY=your_api_key_here
```

## 🏃 Запуск приложения

### Вариант 1: Локальный запуск (рекомендуется)

#### Запуск Backend API
```bash
cd backend
python main.py
```

API будет доступен на `http://localhost:8000`

#### Запуск Frontend
```bash
cd frontend
python -m http.server 3000
```

Или откройте `index.html` напрямую в браузере

Frontend будет доступен на `http://localhost:3000`

### Вариант 2: Production запуск с Docker

```bash
docker-compose up -d
```

## 📁 Структура проекта

```
digital-inspector/
├── backend/
│   ├── main.py              # FastAPI приложение
│   ├── detector.py          # Модуль детекции
│   └── .env                 # Конфигурация (создать)
├── frontend/
│   └── index.html           # Веб-интерфейс
├── models/                  # Обученные модели (добавить свои)
├── uploads/                 # Загруженные документы
├── results/                 # Обработанные результаты
├── requirements.txt         # Python зависимости
├── README.md               # Этот файл
└── docker-compose.yml      # Docker конфигурация
```

## 🎯 Использование

### Веб-интерфейс

1. Откройте `http://localhost:3000` в браузере
2. Нажмите на область загрузки или перетащите документы (PDF, PNG, JPG)
3. Нажмите кнопку **"⚡ Обработать"**
4. Дождитесь завершения обработки
5. Просмотрите результаты:
   - Слева: список документов
   - По центру: предпросмотр с bounding boxes
   - Справа: статистика и список детекций

### API Endpoints

#### Загрузка документов
```bash
POST /api/upload
Content-Type: multipart/form-data

curl -X POST http://localhost:8000/api/upload \
  -F "files=@document1.pdf" \
  -F "files=@document2.jpg"
```

Ответ:
```json
{
  "task_id": "uuid-string",
  "files_uploaded": 2,
  "files": [...]
}
```

#### Обработка документов
```bash
POST /api/process/{task_id}

curl -X POST http://localhost:8000/api/process/your-task-id
```

Ответ:
```json
{
  "task_id": "uuid-string",
  "status": "completed",
  "results": [
    {
      "filename": "document.pdf",
      "pages": 1,
      "total_detections": 5,
      "detections": [
        {
          "type": "qr_code",
          "page": 1,
          "bbox": [100, 150, 200, 250],
          "confidence": 0.95
        },
        ...
      ]
    }
  ]
}
```

#### Получение результатов
```bash
GET /api/results/{task_id}
```

#### Получение обработанного изображения
```bash
GET /api/image/{task_id}/{filename}
```

## 🔧 Конфигурация

### Параметры детекции (backend/detector.py)

```python
# DPI для конвертации PDF (200 = баланс качество/скорость)
self.dpi = 200

# Порог уверенности детекции (0.5 = 50%)
self.confidence_threshold = 0.50

# Диапазон aspect ratio для фильтрации (квадратные объекты)
self.aspect_ratio_range = (0.7, 1.3)
```

### Оптимизация для вашей GPU (RTX 3060 Laptop)

В файле `backend/detector.py` уменьшено DPI до 200 для экономии VRAM. Если хотите больше качества и позволяет память:

```python
self.dpi = 300  # Выше качество, но больше VRAM
```

## 📊 Формат выходных данных

### JSON результаты
```json
{
  "filename": "document.pdf",
  "pages": 2,
  "total_detections": 8,
  "detections": [
    {
      "type": "qr_code",      // Тип: qr_code, stamp, signature
      "page": 1,               // Номер страницы
      "bbox": [x1, y1, x2, y2], // Bounding box
      "confidence": 0.95,      // Уверенность модели
      "width": 100,
      "height": 100
    }
  ],
  "output_image": "processed.jpg",
  "status": "success"
}
```

## 🎨 Добавление своей модели подписей

Когда закончите обучение модели подписей, добавьте её в `backend/detector.py`:

```python
def _init_detectors(self):
    # ... существующий код ...
    
    try:
        # Ваша модель подписей
        import torch
        self.signature_model = torch.load('models/signature_model.pth')
        self.signature_model.eval()
        print("✓ Signature detector loaded")
    except Exception as e:
        print(f"⚠ Signature detector not available: {e}")
```

И реализуйте метод детекции:

```python
def _detect_signatures(self, image: np.ndarray, page_num: int) -> List[Dict]:
    """Детекция подписей"""
    if not self.signature_model:
        return []
    
    detections = []
    
    try:
        # Ваш код инференса модели
        # results = self.signature_model(image)
        # ... обработка результатов ...
        
        pass
    except Exception as e:
        print(f"Signature detection error: {e}")
    
    return detections
```

## 🐛 Troubleshooting

### Ошибка: "No module named 'pdf2image'"
```bash
pip install pdf2image
```

### Ошибка: "PDFInfoNotInstalledError"
Установите Poppler (см. раздел "Установка зависимостей")

### Ошибка: "CUDA out of memory"
Уменьшите DPI в `detector.py`:
```python
self.dpi = 150  # или даже 100
```

### API не отвечает
Проверьте что Backend запущен:
```bash
curl http://localhost:8000/health
```

## 📝 Лицензия

MIT License - свободно используйте для хакатона и дальнейшей разработки

## 👥 Команда

Решение создано для хакатона Armeta AI "Digital Inspector"

## 🙏 Благодарности

- Armeta AI за интересную задачу
- Roboflow за платформу обучения моделей
- OpenCV community

---

**Удачи на хакатоне! 🚀**
