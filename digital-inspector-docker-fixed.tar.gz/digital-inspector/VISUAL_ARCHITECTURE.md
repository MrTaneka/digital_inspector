# 🏗️ Digital Inspector - Визуальная Архитектура

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          🌐 WEB BROWSER                                  │
│                     http://localhost:3000                                │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ HTTP Requests
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                       📱 FRONTEND (HTML/JS)                              │
│  ┌───────────────┐  ┌───────────────────┐  ┌─────────────────────────┐ │
│  │   Documents   │  │    Preview        │  │   Results Panel         │ │
│  │   - Upload    │  │    - Zoom         │  │   - Stats               │ │
│  │   - List      │  │    - Pan          │  │   - Detections          │ │
│  │   - Select    │  │    - Controls     │  │   - Confidence          │ │
│  └───────────────┘  └───────────────────┘  └─────────────────────────┘ │
│                                                                           │
│  Features:                                                                │
│  • Drag & Drop file upload                                               │
│  • Real-time preview with zoom (50%-500%)                                │
│  • Color-coded detection types                                           │
│  • Interactive statistics dashboard                                      │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ REST API (JSON)
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                       🚀 BACKEND API (FastAPI)                           │
│                     http://localhost:8000                                │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │                         API ENDPOINTS                              │  │
│  │  POST   /api/upload                Upload files → task_id         │  │
│  │  POST   /api/process/{task_id}     Process documents              │  │
│  │  GET    /api/results/{task_id}     Get JSON results               │  │
│  │  GET    /api/image/{task_id}/{f}   Get processed image            │  │
│  │  DELETE /api/task/{task_id}        Delete task                    │  │
│  │  GET    /api/tasks                 List all tasks                 │  │
│  │  GET    /health                    Health check                   │  │
│  │  GET    /docs                      API documentation              │  │
│  └───────────────────────────────────────────────────────────────────┘  │
│                                                                           │
│  Features:                                                                │
│  • Async file processing                                                 │
│  • Multi-file upload support                                             │
│  • Task-based processing                                                 │
│  • JSON + Image outputs                                                  │
│  • CORS enabled                                                          │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                                    │ Process Documents
                                    ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    🔍 DOCUMENT DETECTOR                                  │
│  ┌────────────────────────────────────────────────────────────────────┐ │
│  │                      Processing Pipeline                            │ │
│  │                                                                     │ │
│  │  1. INPUT                                                           │ │
│  │     PDF/PNG/JPG → PDF2Image Converter → Images                    │ │
│  │                                                                     │ │
│  │  2. DETECTION                                                       │ │
│  │     ┌─────────────┐  ┌─────────────┐  ┌──────────────┐           │ │
│  │     │ QR Detector │  │   Stamp     │  │  Signature   │           │ │
│  │     │  (QReader)  │  │  Detector   │  │  Detector    │           │ │
│  │     │             │  │ (Roboflow)  │  │  (Custom)    │           │ │
│  │     └─────────────┘  └─────────────┘  └──────────────┘           │ │
│  │            │                │                 │                     │ │
│  │            └────────────────┴─────────────────┘                     │ │
│  │                           │                                          │ │
│  │  3. FILTERING                                                        │ │
│  │     • Color filter (HSV saturation)                                 │ │
│  │     • Geometry filter (aspect ratio)                                │ │
│  │     • Confidence threshold (>50%)                                   │ │
│  │                           │                                          │ │
│  │  4. VISUALIZATION                                                    │ │
│  │     • Draw bounding boxes (color-coded)                             │ │
│  │     • Add confidence labels                                         │ │
│  │     • Generate annotated images                                     │ │
│  │                           │                                          │ │
│  │  5. OUTPUT                                                           │ │
│  │     • JSON with coordinates                                         │ │
│  │     • Processed images/PDFs                                         │ │
│  └────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────┘
                                    │
                 ┌──────────────────┴──────────────────┐
                 ▼                                      ▼
┌─────────────────────────────┐      ┌────────────────────────────────┐
│     📊 JSON OUTPUT          │      │    🖼️ VISUAL OUTPUT            │
│                             │      │                                │
│  {                          │      │  ┌──────────────────────────┐ │
│    "filename": "doc.pdf",   │      │  │                          │ │
│    "pages": 2,              │      │  │    ┌─────┐               │ │
│    "detections": [          │      │  │    │ QR  │  🟢 Green     │ │
│      {                      │      │  │    └─────┘               │ │
│        "type": "qr_code",   │      │  │                          │ │
│        "page": 1,           │      │  │    ┌─────┐               │ │
│        "bbox": [x,y,w,h],   │      │  │    │STAMP│  🔵 Blue      │ │
│        "confidence": 0.95   │      │  │    └─────┘               │ │
│      },                     │      │  │                          │ │
│      ...                    │      │  │    ┌─────┐               │ │
│    ]                        │      │  │    │SIGN │  🔴 Red       │ │
│  }                          │      │  │    └─────┘               │ │
│                             │      │  │                          │ │
│  For API integrations       │      │  └──────────────────────────┘ │
│                             │      │                                │
│                             │      │  For human review              │
└─────────────────────────────┘      └────────────────────────────────┘

```

## 🔄 Data Flow

```
┌───────────┐
│   User    │
│  Uploads  │
│   Files   │
└─────┬─────┘
      │
      ▼
┌───────────────────────────────────────┐
│  1. UPLOAD PHASE                      │
│  • Accept PDF/PNG/JPG                 │
│  • Generate task_id (UUID)            │
│  • Store in uploads/task_id/          │
│  • Create metadata.json               │
└─────┬─────────────────────────────────┘
      │
      ▼
┌───────────────────────────────────────┐
│  2. PROCESSING PHASE                  │
│  • Convert PDF → Images (200 DPI)     │
│  • Run 3 detectors in parallel        │
│  • Filter false positives             │
│  • Annotate images                    │
│  • Generate JSON results              │
└─────┬─────────────────────────────────┘
      │
      ▼
┌───────────────────────────────────────┐
│  3. STORAGE PHASE                     │
│  • Save to results/task_id/           │
│  • Processed images                   │
│  • results.json                       │
│  • Update task status                 │
└─────┬─────────────────────────────────┘
      │
      ▼
┌───────────────────────────────────────┐
│  4. DELIVERY PHASE                    │
│  • Frontend polls /api/results        │
│  • Display annotated images           │
│  • Show statistics                    │
│  • List all detections                │
└───────────────────────────────────────┘
```

## 🧠 Detection Logic

```
┌─────────────────────────────────────────────────────────────┐
│                    IMAGE INPUT                               │
└────────────────────┬────────────────────────────────────────┘
                     │
          ┌──────────┴──────────┐
          ▼                     ▼
┌──────────────────┐   ┌──────────────────┐
│  QR DETECTION    │   │ STAMP DETECTION  │
│                  │   │                  │
│  QReader Large   │   │ Roboflow Model   │
│  • Detect boxes  │   │ • Detect boxes   │
│  • Get coords    │   │ • Get coords     │
│  • Confidence    │   │ • Confidence     │
└────────┬─────────┘   └────────┬─────────┘
         │                      │
         └──────────┬───────────┘
                    ▼
         ┌──────────────────────┐
         │   FILTERING STAGE    │
         │                      │
         │  1. Confidence > 0.5 │
         │  2. Aspect: 0.7-1.3  │
         │  3. Color check      │
         │     (HSV sat < 25)   │
         └──────────┬───────────┘
                    ▼
         ┌──────────────────────┐
         │  VALID DETECTIONS    │
         │  • QR codes          │
         │  • Stamps/Seals      │
         │  • Signatures        │
         └──────────┬───────────┘
                    ▼
         ┌──────────────────────┐
         │   VISUALIZATION      │
         │  • Draw boxes        │
         │  • Add labels        │
         │  • Color code        │
         └──────────┬───────────┘
                    ▼
         ┌──────────────────────┐
         │      OUTPUT          │
         │  • JSON coords       │
         │  • Annotated image   │
         └──────────────────────┘
```

## 🎨 Color Coding System

```
Detection Types and Colors:

🟢 GREEN  → QR Codes
   RGB: (0, 255, 0)
   Use case: Quick verification links

🔵 BLUE   → Stamps/Seals
   RGB: (255, 0, 0) [BGR format]
   Use case: Official validation

🔴 RED    → Signatures
   RGB: (0, 0, 255) [BGR format]
   Use case: Authorization proof
```

## 📦 File Structure

```
digital-inspector/
│
├── 🌐 Frontend Layer
│   └── index.html (600 lines)
│       ├── UI Components
│       ├── API Client
│       └── State Management
│
├── 🔧 Backend Layer
│   ├── main.py (395 lines)
│   │   ├── FastAPI App
│   │   ├── 8 API Endpoints
│   │   └── File Management
│   │
│   └── detector.py (355 lines)
│       ├── DocumentDetector Class
│       ├── 3 Detection Methods
│       ├── Filtering Logic
│       └── Visualization
│
├── 📊 Data Layer
│   ├── uploads/       → Input files
│   ├── results/       → Processed data
│   └── outputs/       → Temp storage
│
└── 📚 Documentation
    ├── README.md      → Main guide
    ├── ARCHITECTURE.md → Technical details
    ├── QUICKSTART.md   → Fast start
    └── COMMANDS.md     → All commands
```

## 💻 Technology Stack

```
┌─────────────────────────────────────────┐
│         FRONTEND STACK                   │
│  • HTML5 + CSS3 (Modern UI)             │
│  • Vanilla JavaScript (No frameworks)   │
│  • Fetch API (Async requests)           │
│  • Canvas API (Image manipulation)      │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         BACKEND STACK                    │
│  • FastAPI 0.115 (Web framework)        │
│  • Uvicorn (ASGI server)                │
│  • Python 3.10+ (Core language)         │
│  • Async/await (Concurrency)            │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         ML/CV STACK                      │
│  • OpenCV 4.10 (Image processing)       │
│  • QReader 3.14 (QR detection)          │
│  • Roboflow/Inference (Custom models)   │
│  • PyTorch 2.0+ (Deep learning)         │
│  • pdf2image (PDF conversion)           │
└─────────────────────────────────────────┘

┌─────────────────────────────────────────┐
│         DEPLOYMENT STACK                 │
│  • Docker (Containerization)            │
│  • docker-compose (Orchestration)       │
│  • Nginx (Reverse proxy)                │
│  • CUDA (GPU acceleration)              │
└─────────────────────────────────────────┘
```

## 🚀 Scaling Architecture

```
         Current (v1.0)              →       Future (v2.0+)
                                    
┌─────────────────┐                ┌──────────────────────────┐
│  Single Server  │                │   Load Balancer          │
│                 │                └────────┬─────────────────┘
│  • FastAPI      │                         │
│  • 1 GPU        │                ┌────────┴────────┐
│  • Local files  │                ▼                 ▼
└─────────────────┘         ┌──────────┐    ┌──────────┐
                            │ Worker 1 │    │ Worker 2 │
  5-10 docs/min             │ GPU 1    │    │ GPU 2    │
                            └────┬─────┘    └────┬─────┘
                                 │               │
                            ┌────┴───────────────┴────┐
                            │   Redis Queue           │
                            │   S3 Storage            │
                            │   PostgreSQL DB         │
                            └─────────────────────────┘
                            
                            100-1000+ docs/min
```

---

_Эта архитектура обеспечивает:_
- ✅ **Модульность** - легко добавлять детекторы
- ✅ **Масштабируемость** - горизонтальное расширение
- ✅ **Надежность** - обработка ошибок на каждом уровне
- ✅ **Производительность** - оптимизация под GPU
- ✅ **Удобство** - простой интерфейс и API

**Digital Inspector - Production-Ready AI Solution 🚀**
