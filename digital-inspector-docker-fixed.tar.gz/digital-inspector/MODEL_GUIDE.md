# 🎯 Гайд по моделям YOLOv8 и оптимизации для GTX 1650 Ti

## 📦 Формат моделей

### Какой формат использовать?

YOLOv8 поддерживает несколько форматов, но для вашей задачи лучше всего:

```
✅ РЕКОМЕНДУЕТСЯ: .pt (PyTorch)
   - Полная поддержка всех функций
   - Легко загружать и использовать
   - Поддержка GPU ускорения
   - Размер: ~6-50 MB в зависимости от модели

⚠️ Альтернативы (не рекомендуется для начала):
   - .onnx - для production, сложнее в использовании
   - .torchscript - для production
   - .engine - TensorRT, требует дополнительной настройки
```

### Структура папки models/

```
digital-inspector/
└── models/
    ├── stamp_model.pt        # Ваша модель для печатей
    ├── signature_model.pt    # Ваша модель для подписей
    └── README.txt            # Описание моделей (опционально)
```

---

## 💾 Как сохранить модель YOLOv8

### Вариант 1: После обучения в Ultralytics

```python
from ultralytics import YOLO

# Обучение модели
model = YOLO('yolov8s.pt')  # s = small, оптимально для вашей GPU
results = model.train(
    data='your_data.yaml',
    epochs=100,
    imgsz=640,
    batch=8,  # Для GTX 1650 Ti (4GB) оптимально 8-16
    device=0   # GPU
)

# Сохранение обученной модели
model.save('stamp_model.pt')  # Сохраняет веса

# ИЛИ сохранить лучшую модель после обучения
# Она будет в runs/detect/train/weights/best.pt
import shutil
shutil.copy('runs/detect/train/weights/best.pt', 'models/stamp_model.pt')
```

### Вариант 2: Использование готовой модели

```python
from ultralytics import YOLO

# Загрузить вашу обученную модель
model = YOLO('path/to/your/trained_model.pt')

# Сохранить в нужную папку
model.save('models/stamp_model.pt')
```

### Вариант 3: Экспорт из Roboflow (если обучали там)

1. Зайдите в Roboflow проект
2. Выберите версию модели
3. Export → Format: PyTorch → Download
4. Переименуйте скачанный файл в `stamp_model.pt`
5. Поместите в папку `models/`

---

## 🎮 GTX 1650 Ti - Оптимизация

### Характеристики вашей GPU:

```
GPU: NVIDIA GTX 1650 Ti (Laptop)
VRAM: 4GB GDDR6
CUDA Cores: 1024
Compute: 7.5
```

### ⚡ Насколько быстро будет работать?

#### Сравнение с другими GPU:

| GPU Model      | VRAM | Скорость (docs/min) | Относительно |
|----------------|------|---------------------|--------------|
| RTX 3060 (12GB)| 12GB | 10-15              | 100%         |
| GTX 1650 Ti    | 4GB  | 5-8                | ~60%         |
| CPU (i7-10gen) | RAM  | 2-3                | ~25%         |

**Вывод:** На GTX 1650 Ti вы потеряете примерно **30-40% скорости** по сравнению с RTX 3060, но это **в 2-3 раза быстрее CPU!**

### 📊 Реальные цифры обработки:

```
YOLOv8s (small) на GTX 1650 Ti:
- Один документ (1 страница, 640x640): ~0.3-0.5 сек
- PDF (5 страниц): ~2-3 сек
- Batch из 10 документов: ~20-30 сек

С учетом PDF конвертации и post-processing:
- 1 документ: ~1-2 сек
- 10 документов: ~15-25 сек
- 100 документов: ~2-4 минуты
```

**Это абсолютно приемлемо для хакатона и даже production!** 🎉

---

## ⚙️ Оптимизация для GTX 1650 Ti

### 1. Настройки в detector.py (уже применены):

```python
# Оптимизировано для 4GB VRAM
self.dpi = 150           # Было 200, снижаем разрешение
self.device = 'cuda'     # Используем GPU
```

### 2. Выбор размера модели YOLOv8:

```python
# ❌ НЕ ИСПОЛЬЗУЙТЕ для 1650 Ti:
yolov8x.pt   # Extra Large - требует 8GB+
yolov8l.pt   # Large - требует 6GB+

# ⚠️ МОЖНО, но будет медленнее:
yolov8m.pt   # Medium - требует 4-5GB (на грани)

# ✅ РЕКОМЕНДУЕТСЯ:
yolov8s.pt   # Small - требует 2-3GB (ОПТИМАЛЬНО!)
yolov8n.pt   # Nano - требует 1-2GB (самый быстрый, но менее точный)
```

**Для вашего хакатона используйте yolov8s!** Баланс скорость/точность.

### 3. Оптимальные параметры обучения:

```python
# training_config.yaml
model = YOLO('yolov8s.pt')

results = model.train(
    data='your_data.yaml',
    epochs=100,              # Достаточно для хорошего результата
    imgsz=640,               # Не увеличивайте! 640 оптимально
    batch=8,                 # 8-12 для 1650 Ti (НЕ 16!)
    device=0,                # GPU
    workers=4,               # CPU workers для загрузки данных
    patience=20,             # Early stopping
    save=True,
    
    # Аугментации (помогают точности без VRAM)
    hsv_h=0.015,
    hsv_s=0.7,
    hsv_v=0.4,
    degrees=10,
    translate=0.1,
    scale=0.5,
    flipud=0.5,
    fliplr=0.5,
    mosaic=1.0,
)
```

### 4. Если не хватает VRAM во время inference:

```python
# В detector.py добавьте:
import torch

# Перед inference
with torch.no_grad():  # Экономит память
    results = self.stamp_model(
        image,
        conf=self.confidence_threshold,
        verbose=False,
        half=True  # FP16 вместо FP32 (в 2 раза меньше памяти!)
    )[0]
```

### 5. Batch processing (если нужна максимальная скорость):

```python
# Обрабатываем несколько изображений за раз
images = [img1, img2, img3]  # Макс 4-6 для 1650 Ti

results = self.stamp_model(
    images,
    conf=self.confidence_threshold,
    verbose=False
)
```

---

## 🔍 Проверка что всё работает

### Тест 1: Проверка GPU

```python
import torch
print(f"CUDA available: {torch.cuda.is_available()}")
print(f"GPU: {torch.cuda.get_device_name(0)}")
print(f"VRAM: {torch.cuda.get_device_properties(0).total_memory / 1e9:.2f} GB")
```

Ожидаемый вывод:
```
CUDA available: True
GPU: NVIDIA GeForce GTX 1650 Ti
VRAM: 4.00 GB
```

### Тест 2: Загрузка модели

```python
from ultralytics import YOLO

model = YOLO('models/stamp_model.pt')
print(f"Model loaded on: {model.device}")
print(f"Model type: {model.task}")
```

### Тест 3: Inference на тестовом изображении

```python
from ultralytics import YOLO
import cv2

model = YOLO('models/stamp_model.pt')
image = cv2.imread('test_document.jpg')

# Засекаем время
import time
start = time.time()

results = model(image, conf=0.5)

end = time.time()
print(f"Inference time: {end - start:.3f} seconds")
print(f"Detections: {len(results[0].boxes)}")
```

---

## 📝 Пошаговая инструкция

### Шаг 1: Обучение модели (на Colab или локально)

```python
from ultralytics import YOLO

# Используйте yolov8s для баланса
model = YOLO('yolov8s.pt')

# Обучение
results = model.train(
    data='stamps.yaml',  # Ваш датасет
    epochs=100,
    imgsz=640,
    batch=8,  # Для 1650 Ti
    device=0
)

# Модель сохранится в runs/detect/train/weights/best.pt
```

### Шаг 2: Копирование модели в проект

```bash
# После обучения
cp runs/detect/train/weights/best.pt digital-inspector/models/stamp_model.pt

# Для модели подписей
cp runs/detect/train2/weights/best.pt digital-inspector/models/signature_model.pt
```

### Шаг 3: Проверка структуры

```bash
digital-inspector/
└── models/
    ├── stamp_model.pt      # ✅ Должен быть
    └── signature_model.pt  # ✅ Должен быть
```

### Шаг 4: Запуск приложения

```bash
cd digital-inspector
./start.sh
```

Приложение автоматически загрузит модели из папки `models/`!

---

## 🎯 Рекомендации для хакатона

### 1. Размер моделей:

```
stamp_model.pt:      ~14-20 MB (yolov8s)
signature_model.pt:  ~14-20 MB (yolov8s)
Итого:              ~30-40 MB
```

Это нормально! GitHub поддерживает файлы до 100 MB.

### 2. Если модели получаются большие (>50 MB):

Используйте Git LFS или загрузите на Google Drive:

```bash
# Git LFS
git lfs install
git lfs track "*.pt"
git add .gitattributes
git add models/*.pt
git commit -m "Add models"
```

### 3. Для презентации:

- Покажите что модели работают на **вашей** laptop GPU
- Подчеркните что **не требуется облако** или API
- Упомяните **оптимизацию для 4GB VRAM**

---

## 📊 Сравнение моделей YOLOv8

| Модель   | Размер | VRAM   | FPS (1650Ti) | mAP  | Рекомендация       |
|----------|--------|--------|--------------|------|--------------------|
| yolov8n  | 6 MB   | 1-2 GB | 45-50        | 37.3 | Быстро, но -точность|
| yolov8s  | 22 MB  | 2-3 GB | 30-35        | 44.9 | ✅ **ОПТИМАЛЬНО**   |
| yolov8m  | 52 MB  | 4-5 GB | 20-25        | 50.2 | Может не влезть    |
| yolov8l  | 87 MB  | 6+ GB  | ❌           | 52.9 | Не для 1650 Ti     |
| yolov8x  | 136 MB | 8+ GB  | ❌           | 53.9 | Не для 1650 Ti     |

---

## 🚨 Troubleshooting

### Проблема 1: CUDA out of memory

**Симптом:**
```
RuntimeError: CUDA out of memory. Tried to allocate X MB
```

**Решение:**
```python
# Снизьте разрешение
self.dpi = 100  # Было 150

# ИЛИ используйте FP16
results = model(image, half=True)

# ИЛИ переключитесь на CPU для одного файла
model.to('cpu')
```

### Проблема 2: Модель не загружается

**Симптом:**
```
FileNotFoundError: models/stamp_model.pt not found
```

**Решение:**
```bash
# Проверьте путь
ls models/

# Должно быть:
stamp_model.pt
signature_model.pt

# Если нет, скопируйте:
cp your_trained_model.pt models/stamp_model.pt
```

### Проблема 3: Медленно работает

**Решение:**
1. Проверьте что используется GPU: `model.device` должен быть `cuda`
2. Снизьте DPI: `self.dpi = 100`
3. Используйте yolov8n вместо yolov8s
4. Убедитесь что drivers обновлены

---

## 💡 Полезные команды

### Узнать информацию о модели:
```python
from ultralytics import YOLO
model = YOLO('models/stamp_model.pt')
print(model.info())
```

### Визуализировать результаты:
```python
results = model('test_image.jpg')
results[0].show()  # Покажет изображение с детекциями
```

### Экспорт в другие форматы:
```python
model.export(format='onnx')  # Для production
```

---

## 🎉 Итого

### Что использовать:

✅ **Формат:** `.pt` (PyTorch)  
✅ **Модель:** `yolov8s` (Small)  
✅ **Расположение:** `models/stamp_model.pt` и `models/signature_model.pt`  
✅ **DPI:** 150 (оптимально для 1650 Ti)  
✅ **Batch:** 1-2 документа за раз  

### Потеря скорости:

📊 **30-40% медленнее чем RTX 3060**, но **2-3x быстрее CPU**  
⏱️ **Реальная скорость:** 5-8 документов/минуту  
✅ **Это более чем достаточно для хакатона!**

### Преимущества:

✅ Работает на вашей laptop GPU  
✅ Не требует облака или API  
✅ Полный контроль над моделями  
✅ Можно демонстрировать офлайн  

---

**Удачи с обучением моделей! 🚀**
