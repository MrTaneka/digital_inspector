# Digital Inspector - Команды и рецепты

## 🚀 Быстрый старт

### Установка
```bash
# Клонировать проект
git clone <your-repo>
cd digital-inspector

# Создать виртуальное окружение
python -m venv venv
source venv/bin/activate  # Linux/Mac
# или
venv\Scripts\activate     # Windows

# Установить зависимости
pip install -r requirements.txt

# Настроить переменные окружения
cp .env.example .env
# Отредактируйте .env и добавьте ваш ROBOFLOW_API_KEY
```

### Запуск
```bash
# Вариант 1: Автоматический запуск всего
./start.sh        # Linux/Mac
start.bat         # Windows

# Вариант 2: Запуск вручную

# Терминал 1: Backend
cd backend
python main.py

# Терминал 2: Frontend
cd frontend
python -m http.server 3000
```

---

## 🧪 Тестирование API

### Через curl

#### 1. Проверка здоровья
```bash
curl http://localhost:8000/health
```

#### 2. Загрузка документа
```bash
curl -X POST http://localhost:8000/api/upload \
  -F "files=@/path/to/document.pdf" \
  -F "files=@/path/to/image.jpg"
```

Ответ:
```json
{
  "task_id": "abc-123-def-456",
  "files_uploaded": 2
}
```

#### 3. Обработка документов
```bash
curl -X POST http://localhost:8000/api/process/abc-123-def-456
```

#### 4. Получение результатов
```bash
curl http://localhost:8000/api/results/abc-123-def-456
```

#### 5. Скачать обработанное изображение
```bash
curl http://localhost:8000/api/image/abc-123-def-456/document_processed.jpg \
  -o result.jpg
```

### Через Python

```python
import requests

# 1. Загрузить файл
files = {'files': open('document.pdf', 'rb')}
response = requests.post('http://localhost:8000/api/upload', files=files)
task_id = response.json()['task_id']

# 2. Обработать
response = requests.post(f'http://localhost:8000/api/process/{task_id}')
results = response.json()

# 3. Получить результаты
response = requests.get(f'http://localhost:8000/api/results/{task_id}')
data = response.json()

print(f"Найдено детекций: {data['results'][0]['total_detections']}")
```

### Через JavaScript (Frontend)

```javascript
// 1. Загрузить файлы
const formData = new FormData();
formData.append('files', fileInput.files[0]);

const uploadRes = await fetch('http://localhost:8000/api/upload', {
  method: 'POST',
  body: formData
});
const { task_id } = await uploadRes.json();

// 2. Обработать
const processRes = await fetch(`http://localhost:8000/api/process/${task_id}`, {
  method: 'POST'
});
const results = await processRes.json();

// 3. Показать результаты
console.log(results);
```

---

## 🔧 Настройка и оптимизация

### Уменьшение использования памяти
```python
# В backend/detector.py
self.dpi = 150  # Было 200, уменьшаем для экономии памяти
```

### Увеличение точности
```python
# В backend/detector.py
self.confidence_threshold = 0.70  # Было 0.50, повышаем для меньше false positives
```

### Запуск на CPU (без GPU)
```bash
# В .env
USE_GPU=false
```

### Batch processing (обработка нескольких файлов)
```python
# В backend/main.py можно добавить:
@app.post("/api/process_batch")
async def process_batch(task_ids: List[str]):
    results = []
    for task_id in task_ids:
        result = await process_documents(task_id)
        results.append(result)
    return results
```

---

## 🐛 Отладка

### Проверить логи backend
```bash
cd backend
python main.py 2>&1 | tee backend.log
```

### Проверить какие порты используются
```bash
# Linux/Mac
lsof -i :8000
lsof -i :3000

# Windows
netstat -ano | findstr :8000
netstat -ano | findstr :3000
```

### Убить процесс на порту
```bash
# Linux/Mac
kill -9 $(lsof -t -i:8000)

# Windows
taskkill /PID <PID> /F
```

### Проверить установку зависимостей
```bash
pip list | grep -E "fastapi|opencv|pillow|qreader"
```

### Тест детектора отдельно
```bash
cd backend
python -c "from detector import DocumentDetector; d = DocumentDetector(); print('OK')"
```

---

## 📦 Deployment

### Docker build
```bash
docker build -t digital-inspector .
docker run -p 8000:8000 digital-inspector
```

### Docker Compose
```bash
docker-compose up -d
docker-compose logs -f
docker-compose down
```

### Production с Nginx

```nginx
# /etc/nginx/sites-available/digital-inspector
server {
    listen 80;
    server_name your-domain.com;

    # Frontend
    location / {
        root /var/www/digital-inspector/frontend;
        index index.html;
    }

    # API
    location /api/ {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

## 🔐 Безопасность

### Добавить API Key authentication
```python
# В backend/main.py
from fastapi.security import APIKeyHeader

api_key_header = APIKeyHeader(name="X-API-Key")

@app.post("/api/upload")
async def upload_documents(
    files: List[UploadFile],
    api_key: str = Depends(api_key_header)
):
    if api_key != os.getenv("API_KEY"):
        raise HTTPException(401, "Invalid API key")
    # ... rest of code
```

### Rate limiting
```python
from slowapi import Limiter
from slowapi.util import get_remote_address

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

@app.post("/api/upload")
@limiter.limit("10/minute")
async def upload_documents(...):
    ...
```

---

## 📊 Мониторинг

### Prometheus metrics
```python
# В backend/main.py
from prometheus_fastapi_instrumentator import Instrumentator

Instrumentator().instrument(app).expose(app)
```

Метрики доступны на `/metrics`

### Health check endpoint
```bash
# Простая проверка
curl http://localhost:8000/health

# С подробностями
curl http://localhost:8000/health?detailed=true
```

---

## 🧹 Очистка

### Удалить все результаты
```bash
rm -rf uploads/* outputs/* results/*
```

### Очистить Python cache
```bash
find . -type d -name "__pycache__" -exec rm -rf {} +
find . -type f -name "*.pyc" -delete
```

### Удалить виртуальное окружение
```bash
rm -rf venv/
```

---

## 📚 Полезные ресурсы

### Документация
- FastAPI: https://fastapi.tiangolo.com/
- OpenCV: https://docs.opencv.org/
- Roboflow: https://docs.roboflow.com/

### Тренировка моделей
- Roboflow Universe: https://universe.roboflow.com/
- YOLOv8: https://docs.ultralytics.com/

### Деплой
- Railway: https://railway.app/
- Render: https://render.com/
- Fly.io: https://fly.io/

---

## 💡 Советы и трюки

### Ускорение обработки
1. Используйте GPU
2. Уменьшите DPI для больших PDF
3. Используйте batch processing
4. Кэшируйте результаты

### Улучшение точности
1. Увеличьте DPI (но медленнее)
2. Используйте ensemble моделей
3. Добавьте post-processing
4. Fine-tune на ваших данных

### Лучший UX
1. Добавьте progress bar
2. Показывайте preview сразу
3. Сохраняйте историю
4. Добавьте export в разных форматах

---

## 🎓 Для хакатона

### Demo script
```bash
# 1. Запустить сервисы
./start.sh

# 2. Открыть в браузере
open http://localhost:3000

# 3. Загрузить тестовый документ
# Drag & drop document.pdf

# 4. Показать обработку
# Click "Обработать"

# 5. Объяснить результаты
# Point to bounding boxes, stats, JSON
```

### Презентация
1. Проблема (30 сек)
2. Решение (30 сек)
3. Demo (90 сек)
4. Технологии (30 сек)
5. Q&A (remainder)

### Backup plan
Если live demo не работает:
1. Показать записанное видео
2. Показать screenshots
3. Объяснить по коду
4. Показать архитектуру

---

**Удачи! 🚀**
